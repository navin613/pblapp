import java.util.*;
import java.io.*;
//This is 10 question of flow control statements topic
class fcb10{
	public static void main(String args[]){
		for(int i=1;i<=10;i++){
			System.out.print(i+"\t");
		}
	}
}