import java.util.*;
import java.io.*;
//This is 4 question of flow control statements topic
class fcb4{
	public static void main(String args[]){
		char ch1 = 'e';
		char ch2 = 'a';
		if((int)ch1 > (int)ch2)
			System.out.println(ch2+","+ch1);
		else
			System.out.println(ch1+","+ch2);
	}
}