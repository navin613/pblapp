import java.util.*;
import java.io.*;
//This is 11 question of flow control statements topic
class fcb11{
	public static void main(String args[]){
		for(int i=23;i<=57;i++){
			if(i==23 || i==57)
				System.out.println(i);
			else{
				if(i%2==0)
					System.out.println(i);
			}
		}
	}
}
				