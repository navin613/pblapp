import java.util.*;
import java.io.*;

public class arr4 {

    public static void main(String[] args) {
        int []a = {48,49,50,51,52,53,54,55,56,57,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90};
        int len = a.length;
        for(int i=0;i<len;i++){
            System.out.println((char)a[i]);
        }
    }
}